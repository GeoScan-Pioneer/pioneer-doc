import proto
import serial.tools.list_ports as list_ports
import math
import sys
import time


class DeviceHub:
    ATTEMPTS = 2

    def __init__(self):
        self.messengers = []

    def __del__(self):
        self.disconnect()

    @staticmethod
    def _get_messenger(dev):
        print(f"Attepmting to connect {dev}")
        try:
            messenger = proto.Messenger(proto.SerialStream(dev, 115200), 'cache')
            messenger.connect()
            messenger.hub.getParamList()
            return messenger
        except:
            print(f"Could not connect to the device {dev}")
            return None

    @staticmethod
    def _write_parameters(messenger, parameters) -> int:
        parsed = 0
        if messenger is None:
            return 0
        for p, k in zip(messenger.hub.parameters.values(), messenger.hub.parameters.keys()):
            for u in parameters:
                if p[0] == u[0]:
                    if math.isclose(a=p[1], b=u[1], rel_tol=1e-5):
                        print('untouched {:s}: value {:f}'.format(p[0], p[1]))
                        parsed += 1
                    else:
                        time.sleep(0.01)
                        messenger.hub.setParam(value=u[1], name=u[0])
                        p0, p1 = messenger.hub.getParam(number=k)
                        if p0 != p[0] or not math.isclose(a=p1, b=u[1], rel_tol=1e-5):
                            print('update error {:s}'.format(p[0]))
                        else:
                            print('successfully updated {:s}: old {:f}, new {:f}'.format(p[0], p[1], p1))
                            parsed += 1

        return parsed

    @staticmethod
    def _check_parameters_not_null(messenger, params) -> bool:
        messenger.hub.getParamList()
        for p, k in zip(messenger.hub.parameters.values(), messenger.hub.parameters.keys()):
            for u in params:
                if p[0] == u:
                    if not math.isclose(p[1], b=0, rel_tol=1e-5):
                        print(f"SUCCESS: checked {p[0]} = {p[1]}")
                    else:
                        print(f"FAILURE: checked {p[0]} = {p[1]}")
                        return False
        return True

    def write_parameters(self, parameters):
        wrote = 0
        for messenger in self.messengers:
            if messenger is not None:
                wrote += DeviceHub._write_parameters(messenger, parameters)
        return wrote > 0

    def check_parameters_not_null(self, parameters):
        succ = False
        for messenger in self.messengers:
            if messenger is not None:
                if DeviceHub._check_parameters_not_null(messenger, parameters):
                    succ = True
        return succ

    def reset(self):
        for messenger in self.messengers:
            try:
                if messenger is not None:
                    for i in range(0, DeviceHub.ATTEMPTS):
                        messenger.hub.sendCommand(18)  # Reset, few attempts in case the message hasn't reached its destination
            except:
                pass

        self.disconnect()

    def disconnect(self):
        for messenger in self.messengers:
            if messenger is not None:
                try:
                    messenger.stop()
                    messenger.stream.close()
                except:
                    pass
        self.messengers = []

    def connect(self):
        self.messengers = [DeviceHub._get_messenger(ports.device) for ports in list_ports.comports()]


PROPERTIES_FILENAME = "par.properties"
PARAM_UMUX = [('BoardPioneerMini_modules_uMux', 2)]
PARAMS_CHECK_NOT_NULL = [
    "Offsets_accel_xOffset",
    "Offsets_accel_yOffset",
    "Offsets_accel_zOffset",
    "Offsets_gyro_xOffset",
    "Offsets_gyro_yOffset",
    "Offsets_gyro_zOffset"
]


def _parse_parameters(filename=PROPERTIES_FILENAME):
    """
    File is supposed to be entirely valid
    :param filename: name of the file
    """
    updater = []
    try:
        with open(filename, 'r') as f:
            updater = f.readlines()
        updater = [tuple(s.split('=')) for s in updater]
        updater = [s for s in updater if len(s) == 2]
        updater = [(s[0].strip(), float(s[1])) for s in updater]
        updater = [s for s in updater if s[0] != 'BoardPioneerMini_modules_uMux']
        return updater
    except:
        print(f'Could not read parameters from "{filename}"')
        return None


def _header(message):
    return f"""\n{message}\n"""


def write_parameters(hub, params):
    hub.connect()
    print(_header("Writing Parameters"))
    # params = _parse_parameters()
    if params is not None:
        hub.write_parameters(params)
        time.sleep(2)
    hub.disconnect()


def reset(hub):
    print(_header("Resetting target"))
    try:
        hub.connect()
        hub.reset()
    except:
        pass
    finally:
        hub.disconnect()


def check_parameters_not_null(hub):
    print(_header("Checking parameters not null"))
    hub.connect()
    if not hub.check_parameters_not_null(PARAMS_CHECK_NOT_NULL):
        input(_header(">> Offset Error. Please press any key to continue... <<"))
    hub.disconnect()


def connect_and_prepare():
    hub = DeviceHub()

    write_parameters(hub, _parse_parameters())
    time.sleep(3)

    reset(hub)
    time.sleep(3)

    check_parameters_not_null(hub)
    time.sleep(3)

    write_parameters(hub, PARAM_UMUX)
    time.sleep(2)

    reset(hub)
    time.sleep(12)


if __name__ == "__main__":
    arg = sys.argv[1]
    hub = DeviceHub()
    if arg == 'writeparameters':
        write_parameters(hub, _parse_parameters())
    elif arg == 'reset':
        reset(hub)
    elif arg == 'umux':
        write_parameters(hub, PARAM_UMUX)
    elif arg == 'checknotnull':
        check_parameters_not_null(hub)